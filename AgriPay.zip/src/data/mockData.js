export const mockPrices = [
  { id: '1', crop: 'Maize', market: 'Techiman', price: 220, unit: '100kg bag', trend: 'up', change: '+5%' },
  { id: '2', crop: 'Cocoa', market: 'Kumasi', price: 1850, unit: '64kg bag', trend: 'up', change: '+2%' },
  { id: '3', crop: 'Cassava', market: 'Ejura', price: 95, unit: '100kg bag', trend: 'down', change: '-3%' },
  { id: '4', crop: 'Tomato', market: 'Techiman', price: 480, unit: 'crate', trend: 'down', change: '-8%' },
  { id: '5', crop: 'Rice (paddy)', market: 'Tamale', price: 310, unit: '100kg bag', trend: 'flat', change: '0%' },
  { id: '6', crop: 'Yam', market: 'Ejura', price: 140, unit: '100 tubers', trend: 'up', change: '+4%' },
  { id: '7', crop: 'Groundnuts', market: 'Tamale', price: 280, unit: '100kg bag', trend: 'up', change: '+7%' },
  { id: '8', crop: 'Sorghum', market: 'Wa', price: 195, unit: '100kg bag', trend: 'flat', change: '0%' },
  { id: '9', crop: 'Plantain', market: 'Kumasi', price: 60, unit: 'bunch', trend: 'up', change: '+10%' },
  { id: '10', crop: 'Onion', market: 'Techiman', price: 320, unit: 'bag (50kg)', trend: 'down', change: '-5%' },
];

export const mockListings = [
  {
    id: 'l1',
    crop: 'Maize',
    quantity: '15 bags',
    quantityNum: 15,
    seller: 'Kwame Asante',
    location: 'Techiman',
    price: 215,
    unit: '100kg bag',
    postedDaysAgo: 1,
    condition: 'Grade A',
    inEscrow: false,
  },
  {
    id: 'l2',
    crop: 'Cocoa',
    quantity: '8 bags',
    quantityNum: 8,
    seller: 'Akosua Boateng',
    location: 'Kumasi',
    price: 1820,
    unit: '64kg bag',
    postedDaysAgo: 2,
    condition: 'Premium',
    inEscrow: true,
  },
  {
    id: 'l3',
    crop: 'Tomato',
    quantity: '20 crates',
    quantityNum: 20,
    seller: 'Yaw Owusu',
    location: 'Techiman',
    price: 460,
    unit: 'crate',
    postedDaysAgo: 0,
    condition: 'Fresh',
    inEscrow: false,
  },
  {
    id: 'l4',
    crop: 'Yam',
    quantity: '50 tubers',
    quantityNum: 50,
    seller: 'Abena Mensah',
    location: 'Ejura',
    price: 135,
    unit: '100 tubers',
    postedDaysAgo: 3,
    condition: 'Grade B',
    inEscrow: false,
  },
  {
    id: 'l5',
    crop: 'Groundnuts',
    quantity: '5 bags',
    quantityNum: 5,
    seller: 'Kofi Adu',
    location: 'Tamale',
    price: 275,
    unit: '100kg bag',
    postedDaysAgo: 1,
    condition: 'Shelled',
    inEscrow: false,
  },
];

export const mockFarmer = {
  id: 'demo-001',
  name: '',
  phone: '',
  region: '',
  registered: false,
  creditScore: 0,
  walletBalance: 0,
  coopGroup: 'Techiman Maize Growers',
  coopSavings: 0,
};

export const mockSubsidyStatus = {
  programme: 'Planting for Food and Jobs',
  status: 'Pending disbursement',
  statusKey: 'pending',
  amount: 350,
  expectedDate: 'Within 5 business days',
  allocatedDate: 'Jun 18, 2025',
  verifiedDate: 'Jun 20, 2025',
  disbursedDate: null,
  items: [
    { label: 'Fertiliser (2 bags)', value: 'GHS 180' },
    { label: 'Improved seeds (3 packs)', value: 'GHS 120' },
    { label: 'Advisory services', value: 'GHS 50' },
  ],
};

export const mockCoopMembers = [
  { id: 'm1', name: 'Kwame Asante', contributions: 850, rank: 1, avatar: 'KA' },
  { id: 'm2', name: 'Abena Mensah', contributions: 720, rank: 2, avatar: 'AM' },
  { id: 'm3', name: 'Yaw Owusu', contributions: 640, rank: 3, avatar: 'YO' },
  { id: 'm4', name: 'Akosua Boateng', contributions: 580, rank: 4, avatar: 'AB' },
  { id: 'm5', name: 'Kofi Adu', contributions: 420, rank: 5, avatar: 'KA' },
];

export const mockCoopContributions = [
  { id: 'c1', date: 'Jun 20', amount: 100, method: 'MTN MoMo' },
  { id: 'c2', date: 'May 20', amount: 100, method: 'MTN MoMo' },
  { id: 'c3', date: 'Apr 20', amount: 150, method: 'Vodafone Cash' },
  { id: 'c4', date: 'Mar 20', amount: 100, method: 'MTN MoMo' },
];

export const mockLoanHistory = [
  {
    id: 'loan1',
    amount: 500,
    status: 'repaid',
    disbursedDate: 'Jan 10, 2025',
    purpose: 'Fertiliser & seeds',
    monthlyPayment: 175,
    term: 3,
  },
  {
    id: 'loan2',
    amount: 800,
    status: 'active',
    disbursedDate: 'Apr 5, 2025',
    purpose: 'Equipment rental',
    monthlyPayment: 290,
    term: 3,
    paidInstallments: 2,
  },
];

export const mockActivity = [
  { id: 'a1', type: 'price', text: 'Maize price rose to GHS 220 in Techiman', time: '2h ago', icon: 'trending-up-outline' },
  { id: 'a2', type: 'coop', text: 'Monthly contribution of GHS 100 recorded', time: 'Yesterday', icon: 'people-outline' },
  { id: 'a3', type: 'market', text: 'Cocoa listing by Akosua B. — GHS 1,820', time: '2 days ago', icon: 'cart-outline' },
  { id: 'a4', type: 'subsidy', text: 'Subsidy allocation verified by district', time: '3 days ago', icon: 'cash-outline' },
];

export const ghanaRegions = [
  'Ashanti', 'Brong-Ahafo', 'Bono', 'Bono East',
  'Central', 'Eastern', 'Greater Accra', 'Northern',
  'North East', 'Oti', 'Savannah', 'Upper East',
  'Upper West', 'Volta', 'Western', 'Western North',
  'Ahafo',
];
