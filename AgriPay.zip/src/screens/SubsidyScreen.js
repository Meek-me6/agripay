import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Header from '../components/Header';
import Badge from '../components/Badge';
import { mockSubsidyStatus } from '../data/mockData';
import { colors, spacing, radius, typography, shadow } from '../theme/colors';

const STEPS = [
  { key: 'allocated',  label: 'Allocated',  icon: 'document-text-outline' },
  { key: 'verified',   label: 'Verified',   icon: 'checkmark-circle-outline' },
  { key: 'pending',    label: 'Processing', icon: 'hourglass-outline' },
  { key: 'disbursed',  label: 'Disbursed',  icon: 'cash-outline' },
];

function getStepIndex(statusKey) {
  const map = { allocated: 0, verified: 1, pending: 2, disbursed: 3 };
  return map[statusKey] ?? 2;
}

function Timeline({ statusKey }) {
  const currentIdx = getStepIndex(statusKey);
  return (
    <View style={styles.timeline}>
      {STEPS.map((step, i) => {
        const done = i < currentIdx;
        const active = i === currentIdx;
        const future = i > currentIdx;
        const color = done ? colors.success : active ? colors.primary : colors.border;
        return (
          <View key={step.key} style={styles.stepRow}>
            <View style={styles.stepLeft}>
              <View style={[styles.stepCircle, { backgroundColor: done || active ? color : colors.borderLight, borderColor: color }]}>
                <Ionicons name={done ? 'checkmark' : step.icon} size={16} color={done || active ? '#fff' : colors.textMuted} />
              </View>
              {i < STEPS.length - 1 && (
                <View style={[styles.stepLine, { backgroundColor: done ? colors.success : colors.border }]} />
              )}
            </View>
            <View style={styles.stepContent}>
              <Text style={[styles.stepLabel, future && { color: colors.textMuted }]}>{step.label}</Text>
              {i === 0 && <Text style={styles.stepDate}>{mockSubsidyStatus.allocatedDate}</Text>}
              {i === 1 && <Text style={styles.stepDate}>{mockSubsidyStatus.verifiedDate}</Text>}
              {i === 2 && active && <Text style={styles.stepDate}>Expected: {mockSubsidyStatus.expectedDate}</Text>}
              {i === 3 && mockSubsidyStatus.disbursedDate && <Text style={styles.stepDate}>{mockSubsidyStatus.disbursedDate}</Text>}
            </View>
          </View>
        );
      })}
    </View>
  );
}

export default function SubsidyScreen() {
  const s = mockSubsidyStatus;
  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <Header title="Subsidy Tracker" subtitle="Government disbursement status" />
      <ScrollView contentContainerStyle={{ padding: spacing.md, paddingBottom: spacing.xl }}>

        {/* Main card */}
        <View style={[styles.card, shadow.md]}>
          <View style={styles.programmeRow}>
            <View style={styles.leafIcon}>
              <Ionicons name="leaf-outline" size={22} color={colors.primary} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.programmeLabel}>Programme</Text>
              <Text style={styles.programmeName}>{s.programme}</Text>
            </View>
            <Badge label={s.status} variant="warning" />
          </View>

          <View style={styles.divider} />

          <View style={styles.amountRow}>
            <View>
              <Text style={styles.amountLabel}>Total allocation</Text>
              <Text style={styles.amount}>GHS {s.amount}</Text>
            </View>
            <View style={{ alignItems: 'flex-end' }}>
              <Text style={styles.amountLabel}>Expected by</Text>
              <Text style={[styles.amountLabel, { color: colors.text, fontWeight: '600' }]}>{s.expectedDate}</Text>
            </View>
          </View>
        </View>

        {/* Timeline */}
        <View style={[styles.card, shadow.sm, { marginTop: spacing.md }]}>
          <Text style={[typography.h4, { marginBottom: spacing.md }]}>Disbursement progress</Text>
          <Timeline statusKey={s.statusKey} />
        </View>

        {/* Breakdown */}
        <View style={[styles.card, shadow.sm, { marginTop: spacing.md }]}>
          <Text style={[typography.h4, { marginBottom: spacing.md }]}>Allocation breakdown</Text>
          {s.items.map((item, i) => (
            <View key={i} style={[styles.breakdownRow, i < s.items.length - 1 && styles.breakdownBorder]}>
              <Text style={styles.breakdownLabel}>{item.label}</Text>
              <Text style={styles.breakdownValue}>{item.value}</Text>
            </View>
          ))}
        </View>

        {/* Info banner */}
        <View style={[styles.infoBanner, shadow.sm]}>
          <Ionicons name="information-circle-outline" size={20} color={colors.blue} />
          <Text style={styles.infoText}>
            Funds are disbursed directly to your verified AgriPay profile via Moolre's Transfers API — no waiting at a district office.
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.card, borderRadius: radius.md, padding: spacing.lg,
  },
  programmeRow: { flexDirection: 'row', alignItems: 'flex-start', gap: spacing.sm },
  leafIcon: {
    width: 44, height: 44, borderRadius: radius.sm,
    backgroundColor: colors.primaryMuted, alignItems: 'center', justifyContent: 'center',
  },
  programmeLabel: { ...typography.label },
  programmeName: { ...typography.h4, marginTop: 2, flex: 1, flexWrap: 'wrap' },
  divider: { height: 1, backgroundColor: colors.borderLight, marginVertical: spacing.md },
  amountRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end' },
  amountLabel: { ...typography.caption },
  amount: { fontSize: 28, fontWeight: '800', color: colors.primary, marginTop: 2 },
  // Timeline
  timeline: { gap: 0 },
  stepRow: { flexDirection: 'row', alignItems: 'flex-start', marginBottom: 0 },
  stepLeft: { alignItems: 'center', width: 36 },
  stepCircle: {
    width: 32, height: 32, borderRadius: 16,
    alignItems: 'center', justifyContent: 'center', borderWidth: 2,
  },
  stepLine: { width: 2, flex: 1, minHeight: 28 },
  stepContent: { flex: 1, paddingLeft: spacing.sm, paddingBottom: spacing.md, paddingTop: 4 },
  stepLabel: { ...typography.h4 },
  stepDate: { ...typography.caption, marginTop: 2 },
  // Breakdown
  breakdownRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 10 },
  breakdownBorder: { borderBottomWidth: 1, borderBottomColor: colors.borderLight },
  breakdownLabel: { ...typography.body, color: colors.text },
  breakdownValue: { ...typography.body, fontWeight: '700', color: colors.primary },
  // Info
  infoBanner: {
    flexDirection: 'row', alignItems: 'flex-start', gap: spacing.sm,
    backgroundColor: colors.blueMuted, borderRadius: radius.sm, padding: spacing.md, marginTop: spacing.md,
  },
  infoText: { flex: 1, fontSize: 13, color: colors.blue, lineHeight: 19 },
});
