import React from 'react';
import { View, ScrollView, StyleSheet, Text, TouchableOpacity } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useFarmer } from '../context/FarmerContext';
import { colors, spacing, radius, typography, shadow } from '../theme/colors';
import { mockActivity } from '../data/mockData';

const QUICK_ACTIONS = [
  { icon: 'trending-up-outline', label: 'Prices', screen: 'Prices', color: colors.primary },
  { icon: 'cart-outline', label: 'Market', screen: 'Marketplace', color: colors.blue },
  { icon: 'cash-outline', label: 'Subsidy', screen: 'Subsidy', color: colors.accent },
  { icon: 'people-outline', label: 'Coop', screen: 'Cooperative', color: '#16A34A' },
  { icon: 'card-outline', label: 'Credit', screen: 'Credit', color: colors.purple },
  { icon: 'person-outline', label: 'Profile', screen: 'Profile', color: colors.coral },
];

function ScoreRing({ score }) {
  const pct = Math.min(score / 850, 1);
  const label = score >= 700 ? 'Excellent' : score >= 550 ? 'Good' : score >= 400 ? 'Fair' : 'Building';
  const col = score >= 700 ? colors.success : score >= 550 ? colors.primary : colors.accent;
  return (
    <View style={styles.scoreWrap}>
      <View style={[styles.scoreRing, { borderColor: col }]}>
        <Text style={[styles.scoreNum, { color: col }]}>{score || '—'}</Text>
        <Text style={styles.scoreLabel}>{label}</Text>
      </View>
      <Text style={styles.scoreSub}>Credit score</Text>
    </View>
  );
}

export default function HomeScreen({ navigation }) {
  const { farmer } = useFarmer();
  const insets = useSafeAreaInsets();
  const firstName = farmer.name?.split(' ')[0] || 'Farmer';

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.background }}
      contentContainerStyle={{ paddingBottom: spacing.xl }}
      showsVerticalScrollIndicator={false}
    >
      {/* Hero header */}
      <View style={[styles.hero, { paddingTop: insets.top + spacing.md }]}>
        <View style={styles.heroTop}>
          <View>
            <Text style={styles.greeting}>Good morning 👋</Text>
            <Text style={styles.heroName}>{firstName}</Text>
            {farmer.region ? <Text style={styles.heroRegion}>{farmer.region} Region</Text> : null}
          </View>
          <TouchableOpacity style={styles.notifBtn} onPress={() => navigation.navigate('Profile')}>
            <Ionicons name="person-circle-outline" size={36} color="#fff" />
          </TouchableOpacity>
        </View>

        {/* Balance + Score */}
        <View style={styles.statsRow}>
          <View style={styles.balanceCard}>
            <Text style={styles.balanceLabel}>Wallet Balance</Text>
            <Text style={styles.balanceAmount}>GHS {(farmer.walletBalance || 0).toFixed(2)}</Text>
            <View style={styles.coopRow}>
              <Ionicons name="people-outline" size={13} color="rgba(255,255,255,0.7)" />
              <Text style={styles.coopText}>{farmer.coopGroup}</Text>
            </View>
          </View>
          <ScoreRing score={farmer.creditScore} />
        </View>
      </View>

      {/* Quick Actions */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Quick actions</Text>
        <View style={styles.actionsGrid}>
          {QUICK_ACTIONS.map(a => (
            <TouchableOpacity
              key={a.screen}
              style={styles.actionItem}
              onPress={() => navigation.navigate(a.screen)}
              activeOpacity={0.75}
            >
              <View style={[styles.actionIcon, { backgroundColor: a.color + '1A' }]}>
                <Ionicons name={a.icon} size={22} color={a.color} />
              </View>
              <Text style={styles.actionLabel}>{a.label}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* Activity Feed */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Recent activity</Text>
        <View style={[styles.feedCard, shadow.sm]}>
          {mockActivity.map((item, i) => (
            <View key={item.id} style={[styles.feedRow, i < mockActivity.length - 1 && styles.feedRowBorder]}>
              <View style={styles.feedIconWrap}>
                <Ionicons name={item.icon} size={18} color={colors.primary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.feedText}>{item.text}</Text>
                <Text style={styles.feedTime}>{item.time}</Text>
              </View>
            </View>
          ))}
        </View>
      </View>

      {/* Feature phone CTA */}
      <View style={[styles.ussdBanner, shadow.sm]}>
        <Ionicons name="phone-portrait-outline" size={20} color={colors.primary} />
        <Text style={styles.ussdText}>
          Fellow farmers without smartphones can dial{' '}
          <Text style={{ fontWeight: '700', color: colors.primary }}>*XXX#</Text>
          {' '}for prices & USSD banking.
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  hero: {
    backgroundColor: colors.primary,
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.xl,
  },
  heroTop: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: spacing.lg },
  greeting: { fontSize: 13, color: 'rgba(255,255,255,0.7)', fontWeight: '500' },
  heroName: { fontSize: 26, fontWeight: '800', color: '#fff', marginTop: 2 },
  heroRegion: { fontSize: 13, color: 'rgba(255,255,255,0.65)', marginTop: 2 },
  notifBtn: { padding: 4 },
  statsRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  balanceCard: {
    flex: 1, backgroundColor: 'rgba(255,255,255,0.15)',
    borderRadius: radius.md, padding: spacing.md,
  },
  balanceLabel: { fontSize: 11, color: 'rgba(255,255,255,0.7)', fontWeight: '600', textTransform: 'uppercase', letterSpacing: 0.5 },
  balanceAmount: { fontSize: 26, fontWeight: '800', color: '#fff', marginTop: 4 },
  coopRow: { flexDirection: 'row', alignItems: 'center', marginTop: spacing.xs, gap: 4 },
  coopText: { fontSize: 11, color: 'rgba(255,255,255,0.65)' },
  scoreWrap: { alignItems: 'center', gap: 6 },
  scoreRing: {
    width: 72, height: 72, borderRadius: 36,
    borderWidth: 4, alignItems: 'center', justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.12)',
  },
  scoreNum: { fontSize: 18, fontWeight: '800' },
  scoreLabel: { fontSize: 9, color: '#fff', fontWeight: '600' },
  scoreSub: { fontSize: 10, color: 'rgba(255,255,255,0.65)' },
  section: { paddingHorizontal: spacing.md, paddingTop: spacing.lg },
  sectionTitle: { ...typography.h4, marginBottom: spacing.sm },
  actionsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
  actionItem: { alignItems: 'center', width: '14%', flex: 1 },
  actionIcon: {
    width: 52, height: 52, borderRadius: radius.md,
    alignItems: 'center', justifyContent: 'center', marginBottom: 6,
  },
  actionLabel: { fontSize: 11, fontWeight: '600', color: colors.text, textAlign: 'center' },
  feedCard: { backgroundColor: colors.card, borderRadius: radius.md, overflow: 'hidden' },
  feedRow: { flexDirection: 'row', alignItems: 'flex-start', padding: spacing.md, gap: spacing.sm },
  feedRowBorder: { borderBottomWidth: 1, borderBottomColor: colors.borderLight },
  feedIconWrap: {
    width: 34, height: 34, borderRadius: radius.sm,
    backgroundColor: colors.primaryMuted, alignItems: 'center', justifyContent: 'center',
  },
  feedText: { fontSize: 13.5, color: colors.text, flex: 1, lineHeight: 19 },
  feedTime: { fontSize: 11.5, color: colors.textMuted, marginTop: 3 },
  ussdBanner: {
    flexDirection: 'row', alignItems: 'flex-start', gap: spacing.sm,
    backgroundColor: colors.primaryMuted, borderRadius: radius.md,
    marginHorizontal: spacing.md, marginTop: spacing.lg, padding: spacing.md,
  },
  ussdText: { fontSize: 13, color: colors.text, flex: 1, lineHeight: 19 },
});
