import React, { useState, useMemo } from 'react';
import {
  View, FlatList, StyleSheet, Text, TextInput,
  TouchableOpacity, RefreshControl,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Header from '../components/Header';
import Badge from '../components/Badge';
import { mockPrices } from '../data/mockData';
import { colors, spacing, radius, typography, shadow } from '../theme/colors';

const ALL = 'All';
const markets = [ALL, ...Array.from(new Set(mockPrices.map(p => p.market)))];

const trendConfig = {
  up:   { icon: 'trending-up',   color: colors.success, bg: colors.successMuted, badge: 'success' },
  down: { icon: 'trending-down', color: colors.danger,  bg: colors.dangerMuted,  badge: 'danger' },
  flat: { icon: 'remove',        color: colors.textMuted, bg: colors.borderLight, badge: 'muted' },
};

function PriceCard({ item }) {
  const t = trendConfig[item.trend] || trendConfig.flat;
  return (
    <View style={[styles.card, shadow.sm]}>
      <View style={[styles.trendDot, { backgroundColor: t.bg }]}>
        <Ionicons name={t.icon} size={16} color={t.color} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={styles.cropName}>{item.crop}</Text>
        <Text style={styles.market}>{item.market}</Text>
      </View>
      <View style={styles.priceCol}>
        <Text style={styles.price}>GHS {item.price}</Text>
        <Text style={styles.unit}>{item.unit}</Text>
        <Badge label={item.change} variant={item.trend === 'up' ? 'success' : item.trend === 'down' ? 'danger' : 'muted'} style={{ marginTop: 4 }} />
      </View>
    </View>
  );
}

export default function PriceBoardScreen() {
  const [search, setSearch] = useState('');
  const [market, setMarket] = useState(ALL);
  const [refreshing, setRefreshing] = useState(false);

  const filtered = useMemo(() => mockPrices.filter(p => {
    const matchSearch = p.crop.toLowerCase().includes(search.toLowerCase());
    const matchMarket = market === ALL || p.market === market;
    return matchSearch && matchMarket;
  }), [search, market]);

  const onRefresh = () => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 700);
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <Header title="Price Board" subtitle="Updated this morning" />

      {/* Search */}
      <View style={styles.searchWrap}>
        <View style={[styles.searchBar, shadow.sm]}>
          <Ionicons name="search-outline" size={18} color={colors.textMuted} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search crop…"
            placeholderTextColor={colors.textLight}
            value={search}
            onChangeText={setSearch}
          />
          {search.length > 0 && (
            <TouchableOpacity onPress={() => setSearch('')}>
              <Ionicons name="close-circle" size={18} color={colors.textMuted} />
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* Market Tabs */}
      <FlatList
        horizontal
        data={markets}
        keyExtractor={m => m}
        contentContainerStyle={styles.tabsRow}
        showsHorizontalScrollIndicator={false}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={[styles.tab, item === market && styles.tabActive]}
            onPress={() => setMarket(item)}
          >
            <Text style={[styles.tabText, item === market && styles.tabTextActive]}>{item}</Text>
          </TouchableOpacity>
        )}
      />

      {/* Prices */}
      <FlatList
        data={filtered}
        keyExtractor={i => i.id}
        contentContainerStyle={{ paddingHorizontal: spacing.md, paddingBottom: spacing.xl, paddingTop: spacing.sm }}
        renderItem={({ item }) => <PriceCard item={item} />}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={[colors.primary]} />}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Ionicons name="search-outline" size={40} color={colors.border} />
            <Text style={styles.emptyText}>No prices match your search</Text>
          </View>
        }
        ListFooterComponent={
          filtered.length > 0 ? (
            <Text style={styles.footer}>
              Prices sourced daily · Feature-phone farmers receive SMS bulletin
            </Text>
          ) : null
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  searchWrap: { paddingHorizontal: spacing.md, paddingTop: spacing.md, paddingBottom: spacing.xs },
  searchBar: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: colors.card, borderRadius: radius.sm,
    paddingHorizontal: spacing.md, paddingVertical: 11, gap: spacing.sm,
  },
  searchInput: { flex: 1, fontSize: 15, color: colors.text },
  tabsRow: { paddingHorizontal: spacing.md, paddingVertical: spacing.sm, gap: spacing.xs },
  tab: {
    paddingHorizontal: spacing.md, paddingVertical: 7,
    borderRadius: radius.full, backgroundColor: colors.card,
    borderWidth: 1, borderColor: colors.border,
  },
  tabActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  tabText: { fontSize: 13, fontWeight: '600', color: colors.textMuted },
  tabTextActive: { color: '#fff' },
  card: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: colors.card, borderRadius: radius.md,
    padding: spacing.md, marginBottom: spacing.sm, gap: spacing.sm,
  },
  trendDot: {
    width: 36, height: 36, borderRadius: radius.sm,
    alignItems: 'center', justifyContent: 'center',
  },
  cropName: { ...typography.h4 },
  market: { ...typography.caption, marginTop: 2 },
  priceCol: { alignItems: 'flex-end' },
  price: { fontSize: 16, fontWeight: '800', color: colors.primary },
  unit: { fontSize: 11, color: colors.textMuted, marginTop: 1 },
  footer: { ...typography.caption, textAlign: 'center', marginTop: spacing.md, lineHeight: 18 },
  empty: { alignItems: 'center', paddingTop: spacing.xxl, gap: spacing.sm },
  emptyText: { ...typography.body, color: colors.textMuted },
});
