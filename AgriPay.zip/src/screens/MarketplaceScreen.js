import React, { useState } from 'react';
import {
  View, FlatList, Text, StyleSheet, TouchableOpacity,
  Alert, Modal, TextInput, KeyboardAvoidingView, Platform, ScrollView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Header from '../components/Header';
import Badge from '../components/Badge';
import { mockListings } from '../data/mockData';
import { colors, spacing, radius, typography, shadow } from '../theme/colors';

const cropEmojis = { Maize: '🌽', Cocoa: '🍫', Tomato: '🍅', Yam: '🍠', Groundnuts: '🥜' };

function ListingCard({ item, onBuy }) {
  const daysAgo = item.postedDaysAgo === 0 ? 'Today' : item.postedDaysAgo === 1 ? 'Yesterday' : `${item.postedDaysAgo}d ago`;
  const emoji = cropEmojis[item.crop] || '🌾';
  return (
    <View style={[styles.card, shadow.sm]}>
      <View style={styles.cardHeader}>
        <View style={styles.emojiWrap}>
          <Text style={{ fontSize: 24 }}>{emoji}</Text>
        </View>
        <View style={{ flex: 1 }}>
          <View style={styles.titleRow}>
            <Text style={styles.crop}>{item.crop}</Text>
            {item.inEscrow && <Badge label="In Escrow" variant="blue" />}
            <Badge label={item.condition} variant="primary" />
          </View>
          <Text style={styles.meta}>{item.quantity} · {item.location}</Text>
          <Text style={styles.seller}>
            <Ionicons name="person-outline" size={12} color={colors.textMuted} /> {item.seller}
          </Text>
        </View>
      </View>
      <View style={styles.cardFooter}>
        <View>
          <Text style={styles.price}>GHS {item.price}</Text>
          <Text style={styles.perUnit}>per {item.unit}</Text>
        </View>
        <View style={styles.cardActions}>
          <Text style={styles.postedTime}>{daysAgo}</Text>
          <TouchableOpacity style={styles.buyBtn} onPress={() => onBuy(item)} activeOpacity={0.85}>
            <Text style={styles.buyBtnText}>Buy</Text>
            <Ionicons name="arrow-forward" size={14} color="#fff" />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

function PostModal({ visible, onClose, insets }) {
  const [crop, setCrop] = useState('');
  const [qty, setQty] = useState('');
  const [price, setPrice] = useState('');
  const canPost = crop.trim() && qty.trim() && price.trim();

  const handlePost = () => {
    Alert.alert('Listing posted!', `Your listing for ${crop} will appear once our team reviews it.`);
    setCrop(''); setQty(''); setPrice('');
    onClose();
  };

  return (
    <Modal visible={visible} animationType="slide" transparent>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={styles.overlay}>
          <View style={[styles.sheet, { paddingBottom: insets.bottom + spacing.md }]}>
            <View style={styles.sheetHandle} />
            <View style={styles.sheetHeader}>
              <Text style={typography.h3}>Post a listing</Text>
              <TouchableOpacity onPress={onClose}>
                <Ionicons name="close" size={24} color={colors.textMuted} />
              </TouchableOpacity>
            </View>

            {[['Crop name', crop, setCrop, 'e.g. Maize', 'default'],
              ['Quantity', qty, setQty, 'e.g. 10 bags', 'default'],
              ['Price per unit (GHS)', price, setPrice, 'e.g. 220', 'numeric']].map(([lbl, val, set, ph, kb]) => (
              <View key={lbl} style={{ marginBottom: spacing.md }}>
                <Text style={styles.inputLabel}>{lbl}</Text>
                <TextInput
                  style={styles.input}
                  placeholder={ph}
                  placeholderTextColor={colors.textLight}
                  value={val}
                  onChangeText={set}
                  keyboardType={kb}
                />
              </View>
            ))}

            <TouchableOpacity
              style={[styles.postBtn, !canPost && { opacity: 0.4 }]}
              disabled={!canPost}
              onPress={handlePost}
            >
              <Text style={styles.postBtnText}>Post listing</Text>
            </TouchableOpacity>
          </View>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

export default function MarketplaceScreen() {
  const insets = useSafeAreaInsets();
  const [listings] = useState(mockListings);
  const [postModal, setPostModal] = useState(false);

  const handleBuy = (item) => {
    Alert.alert(
      `Buy ${item.crop}`,
      `${item.quantity} from ${item.seller} at GHS ${item.price} / ${item.unit}.\n\nPayment collected via Moolre's Payments API into escrow, released on delivery confirmation.`,
      [{ text: 'Cancel', style: 'cancel' }, { text: 'Confirm', style: 'default', onPress: () => {} }]
    );
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <Header
        title="Marketplace"
        subtitle="Escrow-protected trading"
        rightAction={
          <TouchableOpacity onPress={() => setPostModal(true)} style={styles.fabInline}>
            <Ionicons name="add" size={22} color={colors.primary} />
          </TouchableOpacity>
        }
      />
      <FlatList
        data={listings}
        keyExtractor={i => i.id}
        contentContainerStyle={{ padding: spacing.md, paddingBottom: spacing.xxl }}
        renderItem={({ item }) => <ListingCard item={item} onBuy={handleBuy} />}
        ListHeaderComponent={
          <View style={[styles.escrowBanner, shadow.sm]}>
            <Ionicons name="shield-checkmark-outline" size={20} color={colors.blue} />
            <Text style={styles.escrowText}>
              All transactions use <Text style={{ fontWeight: '700' }}>escrow protection</Text> via Moolre's Payments API.
            </Text>
          </View>
        }
      />
      <TouchableOpacity style={[styles.fab, shadow.lg, { bottom: insets.bottom + spacing.md }]} onPress={() => setPostModal(true)}>
        <Ionicons name="add" size={26} color="#fff" />
      </TouchableOpacity>
      <PostModal visible={postModal} onClose={() => setPostModal(false)} insets={insets} />
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.card, borderRadius: radius.md,
    padding: spacing.md, marginBottom: spacing.sm,
  },
  cardHeader: { flexDirection: 'row', gap: spacing.sm, marginBottom: spacing.sm },
  emojiWrap: {
    width: 48, height: 48, borderRadius: radius.sm,
    backgroundColor: colors.primaryMuted, alignItems: 'center', justifyContent: 'center',
  },
  titleRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.xs, flexWrap: 'wrap' },
  crop: { ...typography.h4 },
  meta: { ...typography.caption, marginTop: 3 },
  seller: { ...typography.caption, marginTop: 2 },
  cardFooter: { flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between' },
  price: { fontSize: 18, fontWeight: '800', color: colors.primary },
  perUnit: { ...typography.caption },
  cardActions: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  postedTime: { ...typography.caption },
  buyBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: colors.primary, paddingHorizontal: spacing.md,
    paddingVertical: 9, borderRadius: radius.sm,
  },
  buyBtnText: { color: '#fff', fontWeight: '700', fontSize: 13 },
  escrowBanner: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.sm,
    backgroundColor: colors.blueMuted, borderRadius: radius.sm,
    padding: spacing.md, marginBottom: spacing.md,
  },
  escrowText: { flex: 1, fontSize: 13, color: colors.blue, lineHeight: 18 },
  fab: {
    position: 'absolute', right: spacing.lg,
    width: 56, height: 56, borderRadius: 28,
    backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center',
  },
  fabInline: { width: 36, height: 36, alignItems: 'center', justifyContent: 'center' },
  // Modal
  overlay: { flex: 1, justifyContent: 'flex-end', backgroundColor: colors.overlay },
  sheet: {
    backgroundColor: colors.card, borderTopLeftRadius: radius.xl,
    borderTopRightRadius: radius.xl, padding: spacing.lg,
  },
  sheetHandle: {
    width: 40, height: 4, borderRadius: 2, backgroundColor: colors.border,
    alignSelf: 'center', marginBottom: spacing.md,
  },
  sheetHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: spacing.lg },
  inputLabel: { fontSize: 12, fontWeight: '600', color: colors.textMuted, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: spacing.xs },
  input: {
    borderWidth: 1, borderColor: colors.border, borderRadius: radius.sm,
    paddingHorizontal: spacing.md, paddingVertical: 12, fontSize: 15, color: colors.text,
  },
  postBtn: { backgroundColor: colors.primary, borderRadius: radius.sm, paddingVertical: 15, alignItems: 'center' },
  postBtnText: { color: '#fff', fontWeight: '700', fontSize: 15 },
});
