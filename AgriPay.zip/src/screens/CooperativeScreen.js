import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView,
  TextInput, TouchableOpacity, Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Header from '../components/Header';
import Badge from '../components/Badge';
import { useFarmer } from '../context/FarmerContext';
import { mockCoopMembers, mockCoopContributions } from '../data/mockData';
import { colors, spacing, radius, typography, shadow } from '../theme/colors';

const TOTAL_POOL = mockCoopMembers.reduce((s, m) => s + m.contributions, 0);
const medalColors = ['#F59E0B', '#9CA3AF', '#B45309'];

function AvatarCircle({ initials, rank, size = 36 }) {
  const bg = rank <= 3 ? [colors.primaryMuted, '#EEF2FF', '#FEF3C7'][rank - 1] : colors.borderLight;
  return (
    <View style={[styles.avatar, { width: size, height: size, borderRadius: size / 2, backgroundColor: bg }]}>
      <Text style={[styles.avatarText, { fontSize: size * 0.35 }]}>{initials}</Text>
    </View>
  );
}

export default function CooperativeScreen() {
  const { farmer, updateFarmer } = useFarmer();
  const [amount, setAmount] = useState('');

  const savings = farmer.coopSavings || 0;
  const memberPool = TOTAL_POOL + savings;

  const handleContribute = () => {
    const val = parseFloat(amount);
    if (!val || val <= 0) return;
    updateFarmer({ coopSavings: savings + val });
    setAmount('');
    Alert.alert('✅ Contribution recorded', `GHS ${val.toFixed(2)} added to ${farmer.coopGroup} via Moolre Payments.`);
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <Header title="Cooperative" subtitle={farmer.coopGroup} />
      <ScrollView contentContainerStyle={{ padding: spacing.md, paddingBottom: spacing.xl }}>

        {/* Hero stats */}
        <View style={[styles.heroCard, shadow.md]}>
          <View style={styles.heroTop}>
            <View style={styles.heroIcon}>
              <Ionicons name="people-outline" size={24} color="#fff" />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.heroLabel}>Group Pool</Text>
              <Text style={styles.heroAmount}>GHS {memberPool.toLocaleString()}</Text>
            </View>
            <Badge label={`${mockCoopMembers.length} members`} variant="muted" />
          </View>
          <View style={styles.statRow}>
            <View style={styles.stat}>
              <Text style={styles.statValue}>GHS {savings.toFixed(2)}</Text>
              <Text style={styles.statLabel}>Your savings</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.stat}>
              <Text style={styles.statValue}>{mockCoopContributions.length}</Text>
              <Text style={styles.statLabel}>Contributions</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.stat}>
              <Text style={styles.statValue}>GHS 100</Text>
              <Text style={styles.statLabel}>Monthly target</Text>
            </View>
          </View>
        </View>

        {/* Contribute */}
        <View style={[styles.card, shadow.sm, { marginTop: spacing.md }]}>
          <Text style={typography.h4}>Add contribution</Text>
          <View style={styles.contributeRow}>
            <View style={styles.amountInputWrap}>
              <Text style={styles.ghsPrefix}>GHS</Text>
              <TextInput
                style={styles.amountInput}
                placeholder="0.00"
                placeholderTextColor={colors.textLight}
                keyboardType="numeric"
                value={amount}
                onChangeText={setAmount}
              />
            </View>
            <TouchableOpacity
              style={[styles.contributeBtn, !amount && { opacity: 0.4 }]}
              disabled={!amount}
              onPress={handleContribute}
            >
              <Ionicons name="add" size={20} color="#fff" />
              <Text style={styles.contributeBtnText}>Pay</Text>
            </TouchableOpacity>
          </View>
          <Text style={styles.note}>
            Triggers Moolre Payments API · Collected via mobile money
          </Text>
        </View>

        {/* Leaderboard */}
        <View style={[styles.card, shadow.sm, { marginTop: spacing.md }]}>
          <Text style={[typography.h4, { marginBottom: spacing.md }]}>Leaderboard</Text>
          {mockCoopMembers.map((m) => (
            <View key={m.id} style={styles.leaderRow}>
              <Text style={[styles.rank, m.rank <= 3 && { color: medalColors[m.rank - 1] }]}>
                {m.rank <= 3 ? ['🥇','🥈','🥉'][m.rank - 1] : `#${m.rank}`}
              </Text>
              <AvatarCircle initials={m.avatar} rank={m.rank} />
              <Text style={styles.memberName}>{m.name}</Text>
              <View style={{ flex: 1 }}>
                <View style={[styles.barBg]}>
                  <View style={[styles.barFill, { width: `${Math.round(m.contributions / TOTAL_POOL * 100)}%` }]} />
                </View>
              </View>
              <Text style={styles.memberAmt}>GHS {m.contributions}</Text>
            </View>
          ))}
        </View>

        {/* History */}
        <View style={[styles.card, shadow.sm, { marginTop: spacing.md }]}>
          <Text style={[typography.h4, { marginBottom: spacing.md }]}>Your history</Text>
          {mockCoopContributions.map((c, i) => (
            <View key={c.id} style={[styles.histRow, i < mockCoopContributions.length - 1 && styles.histBorder]}>
              <View style={styles.histIcon}>
                <Ionicons name="arrow-up-outline" size={16} color={colors.success} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.histText}>Contribution · {c.method}</Text>
                <Text style={styles.histDate}>{c.date}</Text>
              </View>
              <Text style={styles.histAmt}>+GHS {c.amount}</Text>
            </View>
          ))}
        </View>

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  heroCard: {
    backgroundColor: colors.primary, borderRadius: radius.lg, padding: spacing.lg,
  },
  heroTop: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginBottom: spacing.md },
  heroIcon: {
    width: 44, height: 44, borderRadius: radius.sm,
    backgroundColor: 'rgba(255,255,255,0.2)', alignItems: 'center', justifyContent: 'center',
  },
  heroLabel: { fontSize: 12, color: 'rgba(255,255,255,0.7)', fontWeight: '600', textTransform: 'uppercase', letterSpacing: 0.5 },
  heroAmount: { fontSize: 26, fontWeight: '800', color: '#fff', marginTop: 2 },
  statRow: { flexDirection: 'row', backgroundColor: 'rgba(255,255,255,0.12)', borderRadius: radius.sm, padding: spacing.md },
  stat: { flex: 1, alignItems: 'center' },
  statValue: { fontSize: 14, fontWeight: '800', color: '#fff' },
  statLabel: { fontSize: 10, color: 'rgba(255,255,255,0.65)', marginTop: 2 },
  statDivider: { width: 1, backgroundColor: 'rgba(255,255,255,0.2)' },
  card: { backgroundColor: colors.card, borderRadius: radius.md, padding: spacing.lg },
  contributeRow: { flexDirection: 'row', gap: spacing.sm, marginTop: spacing.sm, marginBottom: spacing.sm },
  amountInputWrap: {
    flex: 1, flexDirection: 'row', alignItems: 'center',
    borderWidth: 1, borderColor: colors.border, borderRadius: radius.sm,
    paddingHorizontal: spacing.md, backgroundColor: colors.background,
  },
  ghsPrefix: { fontSize: 15, fontWeight: '700', color: colors.textMuted, marginRight: 4 },
  amountInput: { flex: 1, fontSize: 18, fontWeight: '700', color: colors.text, paddingVertical: 13 },
  contributeBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: colors.primary, paddingHorizontal: spacing.lg,
    borderRadius: radius.sm, paddingVertical: 13,
  },
  contributeBtnText: { color: '#fff', fontWeight: '700', fontSize: 15 },
  note: { ...typography.caption, lineHeight: 17 },
  // Leaderboard
  leaderRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginBottom: spacing.sm },
  rank: { width: 28, fontSize: 16, textAlign: 'center', fontWeight: '700', color: colors.textMuted },
  avatar: { alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontWeight: '700', color: colors.text },
  memberName: { fontSize: 13, fontWeight: '600', color: colors.text, width: 80 },
  barBg: { height: 6, backgroundColor: colors.borderLight, borderRadius: 3, overflow: 'hidden' },
  barFill: { height: 6, backgroundColor: colors.primaryLight, borderRadius: 3 },
  memberAmt: { fontSize: 12, fontWeight: '700', color: colors.primary, width: 60, textAlign: 'right' },
  // History
  histRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 10, gap: spacing.sm },
  histBorder: { borderBottomWidth: 1, borderBottomColor: colors.borderLight },
  histIcon: {
    width: 32, height: 32, borderRadius: radius.sm,
    backgroundColor: colors.successMuted, alignItems: 'center', justifyContent: 'center',
  },
  histText: { fontSize: 13.5, color: colors.text },
  histDate: { ...typography.caption, marginTop: 2 },
  histAmt: { fontSize: 14, fontWeight: '800', color: colors.success },
});
