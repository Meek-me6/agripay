import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  KeyboardAvoidingView, Platform, ScrollView, Modal, FlatList,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { colors, spacing, radius, typography, shadow } from '../theme/colors';
import { useFarmer } from '../context/FarmerContext';
import { ghanaRegions } from '../data/mockData';

function Field({ label, children }) {
  return (
    <View style={{ marginBottom: spacing.md }}>
      <Text style={styles.label}>{label}</Text>
      {children}
    </View>
  );
}

export default function RegisterScreen() {
  const { registerFarmer } = useFarmer();
  const insets = useSafeAreaInsets();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [region, setRegion] = useState('');
  const [regionModal, setRegionModal] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const canSubmit = name.trim().length > 1 && phone.trim().length >= 9 && region.length > 0;

  const handleRegister = async () => {
    if (!canSubmit) return;
    setSubmitting(true);
    try {
      await registerFarmer({ name: name.trim(), phone: phone.trim(), region });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: colors.background }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={[styles.container, { paddingTop: insets.top + spacing.xl, paddingBottom: insets.bottom + spacing.xl }]}>

        {/* Branding */}
        <View style={styles.brandRow}>
          <View style={styles.brandIcon}>
            <Text style={{ fontSize: 28 }}>🌾</Text>
          </View>
          <Text style={styles.logo}>AgriPay</Text>
        </View>
        <Text style={styles.tagline}>Prices · Credit · Subsidies · Savings</Text>
        <Text style={styles.sub}>Built for Ghanaian smallholder farmers</Text>

        {/* Form */}
        <View style={[styles.form, shadow.md]}>
          <Text style={styles.formTitle}>Create your profile</Text>

          <Field label="Full name">
            <TextInput
              style={styles.input}
              placeholder="e.g. Kwame Asante"
              placeholderTextColor={colors.textLight}
              value={name}
              onChangeText={setName}
              autoCapitalize="words"
            />
          </Field>

          <Field label="Phone number">
            <View style={styles.phoneRow}>
              <View style={styles.dialCode}>
                <Text style={{ fontSize: 15, color: colors.text }}>🇬🇭 +233</Text>
              </View>
              <TextInput
                style={[styles.input, { flex: 1, borderTopLeftRadius: 0, borderBottomLeftRadius: 0, borderLeftWidth: 0 }]}
                placeholder="024 XXX XXXX"
                placeholderTextColor={colors.textLight}
                keyboardType="phone-pad"
                value={phone}
                onChangeText={setPhone}
              />
            </View>
          </Field>

          <Field label="Region">
            <TouchableOpacity style={styles.picker} onPress={() => setRegionModal(true)}>
              <Text style={region ? styles.pickerText : styles.pickerPlaceholder}>
                {region || 'Select your region'}
              </Text>
              <Ionicons name="chevron-down" size={18} color={colors.textMuted} />
            </TouchableOpacity>
          </Field>

          <TouchableOpacity
            style={[styles.button, !canSubmit && styles.buttonDisabled]}
            disabled={!canSubmit || submitting}
            onPress={handleRegister}
            activeOpacity={0.85}
          >
            {submitting
              ? <Text style={styles.buttonText}>Creating profile…</Text>
              : <>
                  <Text style={styles.buttonText}>Get started</Text>
                  <Ionicons name="arrow-forward" size={18} color="#fff" style={{ marginLeft: spacing.xs }} />
                </>
            }
          </TouchableOpacity>
        </View>

        {/* USSD note */}
        <View style={styles.ussdNote}>
          <Ionicons name="phone-portrait-outline" size={16} color={colors.textMuted} />
          <Text style={styles.ussdText}>
            No smartphone? Farmers can dial <Text style={{ fontWeight: '700', color: colors.primary }}>*XXX#</Text> from any feature phone.
          </Text>
        </View>

      </ScrollView>

      {/* Region Modal */}
      <Modal visible={regionModal} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={[styles.modalSheet, { paddingBottom: insets.bottom + spacing.md }]}>
            <View style={styles.modalHandle} />
            <Text style={[typography.h3, { marginBottom: spacing.md }]}>Select Region</Text>
            <FlatList
              data={ghanaRegions}
              keyExtractor={r => r}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={[styles.regionRow, item === region && styles.regionRowSelected]}
                  onPress={() => { setRegion(item); setRegionModal(false); }}
                >
                  <Text style={[styles.regionText, item === region && { color: colors.primary, fontWeight: '700' }]}>
                    {item}
                  </Text>
                  {item === region && <Ionicons name="checkmark" size={18} color={colors.primary} />}
                </TouchableOpacity>
              )}
            />
          </View>
        </View>
      </Modal>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { paddingHorizontal: spacing.lg, alignItems: 'stretch' },
  brandRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginBottom: spacing.xs },
  brandIcon: {
    width: 52, height: 52, borderRadius: radius.md,
    backgroundColor: colors.primaryMuted, alignItems: 'center', justifyContent: 'center',
    marginRight: spacing.sm,
  },
  logo: { fontSize: 32, fontWeight: '800', color: colors.primary },
  tagline: { fontSize: 15, fontWeight: '600', color: colors.text, textAlign: 'center', marginTop: spacing.xs },
  sub: { fontSize: 13, color: colors.textMuted, textAlign: 'center', marginTop: 4, marginBottom: spacing.xl },
  form: {
    backgroundColor: colors.card, borderRadius: radius.lg,
    padding: spacing.lg, marginBottom: spacing.lg,
  },
  formTitle: { ...typography.h4, marginBottom: spacing.lg },
  label: { fontSize: 12, fontWeight: '600', color: colors.textMuted, marginBottom: spacing.xs, textTransform: 'uppercase', letterSpacing: 0.5 },
  input: {
    borderWidth: 1, borderColor: colors.border, borderRadius: radius.sm,
    paddingHorizontal: spacing.md, paddingVertical: 13,
    fontSize: 15, color: colors.text, backgroundColor: colors.background,
  },
  phoneRow: { flexDirection: 'row' },
  dialCode: {
    borderWidth: 1, borderColor: colors.border, borderRightWidth: 0,
    borderTopLeftRadius: radius.sm, borderBottomLeftRadius: radius.sm,
    paddingHorizontal: spacing.md, paddingVertical: 13,
    backgroundColor: colors.borderLight,
  },
  picker: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    borderWidth: 1, borderColor: colors.border, borderRadius: radius.sm,
    paddingHorizontal: spacing.md, paddingVertical: 13, backgroundColor: colors.background,
  },
  pickerText: { fontSize: 15, color: colors.text },
  pickerPlaceholder: { fontSize: 15, color: colors.textLight },
  button: {
    backgroundColor: colors.primary, borderRadius: radius.sm,
    paddingVertical: 15, alignItems: 'center', justifyContent: 'center',
    flexDirection: 'row', marginTop: spacing.xs,
  },
  buttonDisabled: { opacity: 0.45 },
  buttonText: { color: '#fff', fontWeight: '700', fontSize: 15 },
  ussdNote: {
    flexDirection: 'row', alignItems: 'flex-start', gap: spacing.xs,
    backgroundColor: colors.borderLight, borderRadius: radius.sm,
    padding: spacing.md,
  },
  ussdText: { fontSize: 13, color: colors.textMuted, flex: 1, lineHeight: 19 },
  // Modal
  modalOverlay: { flex: 1, justifyContent: 'flex-end', backgroundColor: colors.overlay },
  modalSheet: {
    backgroundColor: colors.card, borderTopLeftRadius: radius.xl,
    borderTopRightRadius: radius.xl, padding: spacing.lg, maxHeight: '80%',
  },
  modalHandle: {
    width: 40, height: 4, borderRadius: 2, backgroundColor: colors.border,
    alignSelf: 'center', marginBottom: spacing.md,
  },
  regionRow: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingVertical: 13, borderBottomWidth: 1, borderBottomColor: colors.borderLight,
  },
  regionRowSelected: { backgroundColor: colors.primaryMuted, marginHorizontal: -spacing.xs, paddingHorizontal: spacing.xs, borderRadius: radius.sm },
  regionText: { fontSize: 15, color: colors.text },
});
