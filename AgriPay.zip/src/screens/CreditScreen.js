import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView,
  TextInput, TouchableOpacity, Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Header from '../components/Header';
import Badge from '../components/Badge';
import { useFarmer } from '../context/FarmerContext';
import { mockLoanHistory } from '../data/mockData';
import { colors, spacing, radius, typography, shadow } from '../theme/colors';

const MAX_SCORE = 850;

function getScoreColor(score) {
  if (score >= 700) return colors.success;
  if (score >= 550) return colors.primary;
  if (score >= 400) return colors.accent;
  return colors.danger;
}
function getScoreLabel(score) {
  if (score >= 700) return 'Excellent';
  if (score >= 550) return 'Good';
  if (score >= 400) return 'Fair';
  return 'Building';
}

function ScoreRing({ score }) {
  const pct = Math.min(score / MAX_SCORE, 1);
  const col = getScoreColor(score);
  const lbl = getScoreLabel(score);
  return (
    <View style={styles.ringWrap}>
      <View style={[styles.ringOuter, { borderColor: colors.borderLight }]}>
        <View style={[styles.ringInner, { borderColor: col }]}>
          <Text style={[styles.ringScore, { color: col }]}>{score || '—'}</Text>
          <Text style={[styles.ringLabel, { color: col }]}>{lbl}</Text>
          <Text style={styles.ringMax}>/ {MAX_SCORE}</Text>
        </View>
      </View>
      <View style={[styles.ringBar]}>
        <View style={[styles.ringFill, { width: `${pct * 100}%`, backgroundColor: col }]} />
      </View>
      <Text style={typography.caption}>Credit score</Text>
    </View>
  );
}

const FACTORS = [
  { icon: 'trending-up-outline', label: 'Price Board checks', points: '+25 pts', done: true },
  { icon: 'cart-outline',        label: 'Marketplace sales',  points: '+50 pts', done: false },
  { icon: 'people-outline',      label: 'Coop contributions', points: '+30 pts', done: true },
  { icon: 'cash-outline',        label: 'Subsidy received',   points: '+20 pts', done: false },
];

export default function CreditScreen() {
  const { farmer } = useFarmer();
  const [amount, setAmount] = useState('');
  const [term, setTerm] = useState(3);
  const score = farmer.creditScore || 0;
  const maxLoan = Math.floor(score * 2.5);

  const monthly = amount && term
    ? ((parseFloat(amount) || 0) * 1.08 / term).toFixed(2)
    : null;

  const handleApply = () => {
    const val = parseFloat(amount);
    if (!val || val <= 0) return;
    if (val > maxLoan) {
      Alert.alert('Exceeds limit', `Based on your score of ${score}, maximum loan is GHS ${maxLoan}.`);
      return;
    }
    Alert.alert(
      '✅ Application submitted',
      `Loan of GHS ${val} for ${term} months at 8% p.a. submitted.\n\nIf approved, Moolre's Transfers API disburses funds directly to your profile.`
    );
    setAmount('');
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <Header title="Credit" subtitle="Your history is your collateral" />
      <ScrollView contentContainerStyle={{ padding: spacing.md, paddingBottom: spacing.xl }}>

        {/* Score Card */}
        <View style={[styles.scoreCard, shadow.md]}>
          <ScoreRing score={score} />
          <View style={styles.scoreMeta}>
            <Text style={[typography.h4, { color: '#fff' }]}>Your credit profile</Text>
            <Text style={[typography.caption, { color: 'rgba(255,255,255,0.7)', marginTop: 4 }]}>
              Max loan: <Text style={{ fontWeight: '800', color: '#fff' }}>GHS {maxLoan.toLocaleString()}</Text>
            </Text>
          </View>
        </View>

        {/* Score factors */}
        <View style={[styles.card, shadow.sm, { marginTop: spacing.md }]}>
          <Text style={[typography.h4, { marginBottom: spacing.md }]}>Score boosters</Text>
          {FACTORS.map(f => (
            <View key={f.label} style={styles.factorRow}>
              <View style={[styles.factorIcon, { backgroundColor: f.done ? colors.successMuted : colors.borderLight }]}>
                <Ionicons name={f.icon} size={16} color={f.done ? colors.success : colors.textMuted} />
              </View>
              <Text style={[styles.factorLabel, !f.done && { color: colors.textMuted }]}>{f.label}</Text>
              <Badge label={f.points} variant={f.done ? 'success' : 'muted'} />
              {f.done && <Ionicons name="checkmark-circle" size={18} color={colors.success} />}
            </View>
          ))}
        </View>

        {/* Loan Calculator */}
        <View style={[styles.card, shadow.sm, { marginTop: spacing.md }]}>
          <Text style={[typography.h4, { marginBottom: spacing.md }]}>Loan calculator</Text>

          <Text style={styles.inputLabel}>Amount (GHS)</Text>
          <TextInput
            style={styles.input}
            placeholder={`Max: GHS ${maxLoan}`}
            placeholderTextColor={colors.textLight}
            keyboardType="numeric"
            value={amount}
            onChangeText={setAmount}
          />

          <Text style={[styles.inputLabel, { marginTop: spacing.sm }]}>Term (months)</Text>
          <View style={styles.termRow}>
            {[3, 6, 12].map(t => (
              <TouchableOpacity
                key={t}
                style={[styles.termBtn, term === t && styles.termBtnActive]}
                onPress={() => setTerm(t)}
              >
                <Text style={[styles.termBtnText, term === t && styles.termBtnTextActive]}>{t}mo</Text>
              </TouchableOpacity>
            ))}
          </View>

          {monthly && (
            <View style={styles.calcResult}>
              <Ionicons name="calculator-outline" size={18} color={colors.primary} />
              <Text style={styles.calcText}>
                Monthly repayment: <Text style={{ fontWeight: '800', color: colors.primary }}>GHS {monthly}</Text>
                {'  '}(8% p.a.)
              </Text>
            </View>
          )}

          <TouchableOpacity
            style={[styles.applyBtn, !amount && { opacity: 0.4 }]}
            disabled={!amount}
            onPress={handleApply}
          >
            <Text style={styles.applyBtnText}>Apply for credit</Text>
          </TouchableOpacity>
        </View>

        {/* Loan history */}
        {mockLoanHistory.length > 0 && (
          <View style={[styles.card, shadow.sm, { marginTop: spacing.md }]}>
            <Text style={[typography.h4, { marginBottom: spacing.md }]}>Loan history</Text>
            {mockLoanHistory.map((loan, i) => (
              <View key={loan.id} style={[styles.loanRow, i < mockLoanHistory.length - 1 && styles.loanBorder]}>
                <View style={{ flex: 1 }}>
                  <View style={styles.loanTitleRow}>
                    <Text style={styles.loanAmount}>GHS {loan.amount}</Text>
                    <Badge
                      label={loan.status === 'repaid' ? 'Repaid' : 'Active'}
                      variant={loan.status === 'repaid' ? 'success' : 'blue'}
                    />
                  </View>
                  <Text style={typography.caption}>{loan.purpose} · {loan.disbursedDate}</Text>
                  {loan.status === 'active' && (
                    <Text style={[typography.caption, { marginTop: 2, color: colors.primary }]}>
                      {loan.paidInstallments}/{loan.term} installments paid · GHS {loan.monthlyPayment}/mo
                    </Text>
                  )}
                </View>
              </View>
            ))}
          </View>
        )}

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  scoreCard: {
    backgroundColor: colors.primary, borderRadius: radius.lg,
    padding: spacing.lg, flexDirection: 'row', alignItems: 'center', gap: spacing.lg,
  },
  ringWrap: { alignItems: 'center', gap: 6 },
  ringOuter: {
    width: 90, height: 90, borderRadius: 45,
    borderWidth: 3, alignItems: 'center', justifyContent: 'center',
  },
  ringInner: {
    width: 78, height: 78, borderRadius: 39,
    borderWidth: 4, alignItems: 'center', justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.1)',
  },
  ringScore: { fontSize: 22, fontWeight: '800' },
  ringLabel: { fontSize: 9, fontWeight: '700', marginTop: 1 },
  ringMax: { fontSize: 9, color: 'rgba(255,255,255,0.5)' },
  ringBar: {
    width: 90, height: 4, backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 2, overflow: 'hidden',
  },
  ringFill: { height: 4, borderRadius: 2 },
  scoreMeta: { flex: 1 },
  card: { backgroundColor: colors.card, borderRadius: radius.md, padding: spacing.lg },
  factorRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginBottom: spacing.sm },
  factorIcon: { width: 32, height: 32, borderRadius: radius.xs, alignItems: 'center', justifyContent: 'center' },
  factorLabel: { flex: 1, fontSize: 13.5, fontWeight: '500', color: colors.text },
  inputLabel: { fontSize: 12, fontWeight: '600', color: colors.textMuted, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: spacing.xs },
  input: {
    borderWidth: 1, borderColor: colors.border, borderRadius: radius.sm,
    paddingHorizontal: spacing.md, paddingVertical: 13, fontSize: 16, color: colors.text,
  },
  termRow: { flexDirection: 'row', gap: spacing.sm },
  termBtn: {
    flex: 1, paddingVertical: 10, alignItems: 'center', borderRadius: radius.sm,
    backgroundColor: colors.borderLight, borderWidth: 1, borderColor: colors.border,
  },
  termBtnActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  termBtnText: { fontSize: 14, fontWeight: '600', color: colors.textMuted },
  termBtnTextActive: { color: '#fff' },
  calcResult: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.sm,
    backgroundColor: colors.primaryMuted, borderRadius: radius.sm,
    padding: spacing.md, marginTop: spacing.md,
  },
  calcText: { fontSize: 14, color: colors.text },
  applyBtn: {
    backgroundColor: colors.primary, borderRadius: radius.sm,
    paddingVertical: 15, alignItems: 'center', marginTop: spacing.md,
  },
  applyBtnText: { color: '#fff', fontWeight: '700', fontSize: 15 },
  loanRow: { paddingVertical: spacing.sm },
  loanBorder: { borderBottomWidth: 1, borderBottomColor: colors.borderLight },
  loanTitleRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginBottom: 4 },
  loanAmount: { fontSize: 16, fontWeight: '800', color: colors.text },
});
